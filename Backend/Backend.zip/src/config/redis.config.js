import { Redis as UpstashRedis } from "@upstash/redis";
import dotenv from "dotenv";

dotenv.config();

// ------------------------------
// Check required environment variables
// ------------------------------
const upstashUrl = process.env.UPSTASH_REDIS_REST_URL;
const upstashToken = process.env.UPSTASH_REDIS_REST_TOKEN;

if (!upstashUrl || !upstashToken) {
  const missing = [];
  if (!upstashUrl) missing.push("UPSTASH_REDIS_REST_URL");
  if (!upstashToken) missing.push("UPSTASH_REDIS_REST_TOKEN");
  
  throw new Error(
    `❌ Redis initialization failed: Missing required environment variables: ${missing.join(", ")}`
  );
}

// ------------------------------
// Initialize Upstash Redis client
// ------------------------------
console.log("🚀 Initializing Upstash Redis client...");

const client = new UpstashRedis({
  url: upstashUrl,
  token: upstashToken,
});

// ------------------------------
// Create adapter with consistent method names
// ------------------------------
const redisClient = {
  setEx: (key, ttl, value) => {
    // Stringify all values to ensure consistent behavior
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    return client.setex(key, ttl, serialized);
  },
  get: async (key) => {
    const result = await client.get(key);
    // If result is already an object (Upstash auto-parsed it), return it as-is
    // If it's a string, try to parse it as JSON, if fails, return as string
    if (typeof result === 'object' && result !== null) {
      return result;
    }
    if (typeof result === 'string') {
      try {
        return JSON.parse(result);
      } catch {
        return result;
      }
    }
    return result;
  },
  del: (key) => client.del(key),
  ping: () => client.ping(),
};

// ------------------------------
// Health check function
// ------------------------------
export const checkRedisHealth = async () => {
  try {
    await redisClient.ping();
    console.log("✅ Upstash Redis connection successful");
    return true;
  } catch (error) {
    console.error("❌ Upstash Redis connection failed:", error);
    return false;
  }
};

// ------------------------------
// Run health check on startup
// ------------------------------
checkRedisHealth();

export default redisClient;
