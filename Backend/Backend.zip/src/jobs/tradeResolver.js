import cron from 'node-cron';
import pool, { query } from '../config/db.config.js';
import priceService from '../services/price.service.js';
import walletService from '../services/wallet.service.js';
import tradingGateService from '../services/trading-gate.service.js';
import auditService from '../services/audit.service.js';
import notificationService from '../services/notification.service.js';

/**
 * Calculate real profit percentage based on entry and close price for a binary trade
 * @param {number} entryPrice - Price when trade was opened
 * @param {number} closePrice - Price when trade was closed
 * @param {string} direction - "BUY" or "SELL"
 * @returns {number} Profit percentage (e.g., 5 for 5% profit)
 */
const calculateProfitPercentage = (entryPrice, closePrice, direction) => {
  if (direction === 'BUY') {
    // For BUY: profit if close > entry
    return ((closePrice - entryPrice) / entryPrice) * 100;
  } else {
    // For SELL: profit if close < entry
    return ((entryPrice - closePrice) / entryPrice) * 100;
  }
};

// Helper to get binary settings
const getBinarySettings = async () => {
  const result = await query('SELECT * FROM binary_settings LIMIT 1');
  if (result.rows.length === 0) {
    throw new Error('Binary settings not found');
  }
  return result.rows[0];
};

/**
 * Resolve a single binary trade.
 *
 * Gate OPEN   → always WIN (fixed payout percentage from settings)
 * Gate CLOSED → always LOSE (no further deduction)
 */
const resolveTrade = async (trade, gateOpen) => {
    const traceId = `resolve-${trade.id}-${Date.now()}`;
    console.log(`\n[${traceId}] ====== [resolveTrade] START ======`);
    console.log(`[${traceId}] Trade details:`, {
        tradeId: trade.id,
        userId: trade.user_id,
        pair: trade.pair,
        direction: trade.direction,
        amount: trade.amount,
        entryPrice: trade.entry_price,
        gateOpen: gateOpen
    });
    
    const client = await pool.connect();
    try {
        console.log(`[${traceId}] Step 1: Starting transaction`);
        await client.query('BEGIN');

        // Step 1.5: Lock the binary_trades row and check its current status
        console.log(`[${traceId}] Step 1.5: Locking binary_trades row and checking status`);
        const tradeLockResult = await client.query(
            `SELECT status FROM binary_trades WHERE id = $1 FOR UPDATE`,
            [trade.id]
        );
        
        if (tradeLockResult.rows.length === 0) {
            console.log(`[${traceId}] Trade not found, skipping`);
            await client.query('ROLLBACK');
            return;
        }
        
        const currentStatus = tradeLockResult.rows[0].status;
        if (currentStatus !== 'running') {
            console.log(`[${traceId}] Trade is already resolved (status: ${currentStatus}), skipping`);
            await client.query('ROLLBACK');
            return;
        }

        // Fetch close price (just for record keeping)
        console.log(`[${traceId}] Step 2: Fetching close price for pair:`, trade.pair);
        let closePrice = parseFloat(trade.entry_price);
        try {
            closePrice = await priceService.getPrice(trade.pair);
            console.log(`[${traceId}] Got close price:`, closePrice);
        } catch (err) {
            console.warn(`[${traceId}] ⚠️ Could not fetch price, using entry price: ${err.message}`);
        }

        // Get wallet id for transaction record
        console.log(`[${traceId}] Step 3: Fetching USDT wallet id`);
        const walletRow = await client.query(
            `SELECT id, balance, locked_balance FROM wallets WHERE user_id = $1 AND currency = 'USDT' LIMIT 1`,
            [trade.user_id]
        );
        const walletId = walletRow.rows[0]?.id ?? null;
        console.log(`[${traceId}] Wallet info:`, {
            walletId,
            balance: walletRow.rows[0]?.balance,
            locked_balance: walletRow.rows[0]?.locked_balance
        });

        if (gateOpen) {
            console.log(`[${traceId}] Gate is OPEN → USER WINS`);
            console.log(`[${traceId}] Step 4: Getting binary settings`);
            const settings = await getBinarySettings();
            console.log(`[${traceId}] Settings:`, { 
                payout_percentage: settings.payout_percentage,
                duration_payouts: settings.duration_payouts,
                trade_duration: trade.duration 
            });
            
            // Get duration-specific payout percentage, fall back to global payout_percentage
            const durationKey = String(trade.duration);
            let profitPercentage = settings.payout_percentage;
            
            if (settings.duration_payouts && settings.duration_payouts[durationKey] !== undefined) {
                profitPercentage = parseFloat(settings.duration_payouts[durationKey]);
                console.log(`[${traceId}] Using duration-specific payout: ${profitPercentage}% for ${trade.duration}s`);
            } else {
                console.log(`[${traceId}] No specific payout for ${trade.duration}s, using global: ${profitPercentage}%`);
            }
            
            const profit = (parseFloat(trade.amount) * profitPercentage) / 100;
            const payout = parseFloat(trade.amount) + profit;
            console.log(`[${traceId}] Calculations:`, {
                profitPercentage: `${profitPercentage}%`,
                profitAmount: profit,
                payoutAmount: payout
            });

            console.log(`[${traceId}] Step 5: Releasing original amount from locked balance`);
            await walletService.release(trade.user_id, 'USDT', parseFloat(trade.amount), client);
            console.log(`[${traceId}] ✅ Original amount released`);

            console.log(`[${traceId}] Step 6: Adding profit to balance`);
            await walletService.add(trade.user_id, profit, 'TRADE_WIN', client);
            console.log(`[${traceId}] ✅ Profit added`);

            console.log(`[${traceId}] Step 7: Updating trade status to WIN`);
            await client.query(
                `UPDATE binary_trades
                 SET status = 'win', close_price = $1, payout = $2, resolved_at = CURRENT_TIMESTAMP
                 WHERE id = $3`,
                [closePrice, payout, trade.id]
            );
            console.log(`[${traceId}] ✅ Trade status updated`);

            await client.query('COMMIT');
            console.log(`[${traceId}] ✅ Transaction committed`);
            
            console.log(`[${traceId}] ====== [resolveTrade] SUCCESS (WIN) ======\n`);

            // Audit log (fire-and-forget, outside transaction)
            auditService.createAudit({
                userId: trade.user_id,
                action: 'Trade settled as WIN',
                entityType: 'binary_trade',
                entityId: trade.id,
                metadata: { tradeId: trade.id, amount: trade.amount, profitPercentage, payout, closePrice, marketStatus: 'open' },
            }).catch(e => console.error(`[${traceId}] Audit log failed:`, e.message));

            // User notification (fire-and-forget)
            notificationService.sendToUser({
                userId: trade.user_id,
                type: 'TRADE_WIN',
                title: '🎉 Trade Won!',
                body: `Your ${trade.pair} trade settled as a WIN with ${profitPercentage.toFixed(2)}% profit! Payout: ${payout.toFixed(2)} USDT`,
                metadata: { tradeId: trade.id, profitPercentage, payout, pair: trade.pair },
            }).catch(e => console.error(`[${traceId}] Notification failed:`, e.message));

        } else {
            console.log(`[${traceId}] Gate is CLOSED → USER LOSES`);

            console.log(`[${traceId}] Step 4: Burning locked amount`);
            await walletService.burn(trade.user_id, 'USDT', parseFloat(trade.amount), client);
            console.log(`[${traceId}] ✅ Amount burned`);

            // Record TRADE_LOSS transaction
            console.log(`[${traceId}] Step 4a: Recording TRADE_LOSS transaction`);
            await client.query(
                `INSERT INTO transactions (user_id, wallet_id, type, currency, amount, fee, status, confirmed_at)
                 VALUES ($1, $2, 'TRADE_LOSS', 'USDT', $3, 0, 'completed', CURRENT_TIMESTAMP)`,
                [trade.user_id, walletId, trade.amount]
            );

            console.log(`[${traceId}] Step 5: Updating trade status to LOSE`);
            await client.query(
                `UPDATE binary_trades
                 SET status = 'lose', close_price = $1, payout = 0, resolved_at = CURRENT_TIMESTAMP
                 WHERE id = $2`,
                [closePrice, trade.id]
            );
            console.log(`[${traceId}] ✅ Trade status updated`);

            await client.query('COMMIT');
            console.log(`[${traceId}] ✅ Transaction committed`);
            
            console.log(`[${traceId}] ====== [resolveTrade] SUCCESS (LOSE) ======\n`);

            // Audit log (fire-and-forget)
            auditService.createAudit({
                userId: trade.user_id,
                action: 'Trade settled as LOSS - market closed',
                entityType: 'binary_trade',
                entityId: trade.id,
                metadata: { tradeId: trade.id, amount: trade.amount, payout: 0, closePrice, marketStatus: 'closed' },
            }).catch(e => console.error(`[${traceId}] Audit log failed:`, e.message));

            // User notification (fire-and-forget)
            notificationService.sendToUser({
                userId: trade.user_id,
                type: 'TRADE_LOSS',
                title: '📉 Trade Settled',
                body: `Your ${trade.pair} trade was settled. Amount of ${parseFloat(trade.amount).toFixed(2)} USDT has been deducted.`,
                metadata: { tradeId: trade.id, amount: trade.amount, pair: trade.pair },
            }).catch(e => console.error(`[${traceId}] Notification failed:`, e.message));
        }

    } catch (error) {
        console.error(`[${traceId}] ❌ Error in transaction, rolling back:`, {
            message: error.message,
            stack: error.stack
        });
        await client.query('ROLLBACK');
        console.error(`[${traceId}] ❌ ====== [resolveTrade] FAILED ======\n`);
    } finally {
        console.log(`[${traceId}] Releasing database client`);
        client.release();
    }
};

let resolverTask = null;
let isResolving = false;

/**
 * Binary Trade Resolver - Runs every 5 seconds
 * Resolves expired binary trades.
 * Only resolves expired trades, even if gate is closed.
 */
const resolveExpiredTrades = async () => {
  if (isResolving) {
    console.log('⏭️ Binary trade resolver still running, skipping this tick');
    return;
  }

  isResolving = true;
  console.log('🔄 Running binary trade resolver...');

  try {
    // Find all running trades that have EXPIRED using the server's current time to avoid clock/timezone drift
    const expiredTrades = await query(`
      SELECT id, user_id, pair, direction, amount, entry_price, duration
      FROM binary_trades
      WHERE status = 'running' AND expires_at <= $1
      ORDER BY expires_at ASC
    `, [new Date()]);

    if (expiredTrades.rows.length === 0) {
      console.log('✅ No expired trades to resolve');
      return;
    }

    console.log(`📊 Found ${expiredTrades.rows.length} expired trade(s) to resolve`);

    for (const trade of expiredTrades.rows) {
      // Check CURRENT gate status when resolving each trade
      const isGateOpenNow = await tradingGateService.isTradingOpen();
      if (!isGateOpenNow) {
        console.log(`🔴 Trading gate is CLOSED when resolving trade ${trade.id}`);
      }
      await resolveTrade(trade, isGateOpenNow);
    }

    console.log('✅ Binary trade resolver completed');

  } catch (error) {
    console.error('❌ Trade resolver job error:', error.message);
  } finally {
    isResolving = false;
  }
};

export const startBinaryTradeResolver = () => {
  if (resolverTask) {
    return resolverTask;
  }

  resolverTask = cron.schedule('*/5 * * * * *', resolveExpiredTrades);
  console.log('🚀 Binary trade resolver cron job started (runs every 5 seconds)');
  return resolverTask;
};

export const stopBinaryTradeResolver = () => {
  if (!resolverTask) {
    return;
  }

  resolverTask.stop();
  resolverTask = null;
  console.log('🛑 Binary trade resolver cron job stopped');
};

export default resolveExpiredTrades;
