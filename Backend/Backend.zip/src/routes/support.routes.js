import { Router } from 'express';
import SupportController from '../controllers/support.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.midlware.js';

const router = Router();

// Public routes (no authentication required)

// Get FAQs (public access)
// GET /api/support/faqs?category=trading
router.get('/faqs', SupportController.getFAQs);

// Protected routes (authentication required)

// Create support ticket (authenticated users only)
// POST /api/support/tickets
router.post('/tickets', authenticateToken, SupportController.createTicket);

// Get user's support tickets
// GET /api/support/my-tickets?status=open&limit=20
router.get('/my-tickets', authenticateToken, SupportController.getUserTickets);

// Get specific ticket details
// GET /api/support/tickets/:id
router.get('/tickets/:id', authenticateToken, SupportController.getTicketById);

// User reply to ticket
// POST /api/support/tickets/:id/reply
router.post('/tickets/:id/reply', authenticateToken, SupportController.userReplyToTicket);

// ============================================================================
// ADMIN ONLY ROUTES — middleware applied per-route, not globally
// ============================================================================

// Get all tickets (admin)
router.get('/admin/tickets',              authenticateToken, requireAdmin, SupportController.getAllTickets);
router.get('/admin/counts',               authenticateToken, requireAdmin, SupportController.getTicketCounts);
router.get('/admin/tickets/:id/details',  authenticateToken, requireAdmin, SupportController.getTicketWithReplies);
router.post('/admin/tickets/:id/reply',   authenticateToken, requireAdmin, SupportController.replyToTicket);
router.post('/admin/tickets/:id/close',   authenticateToken, requireAdmin, SupportController.closeTicket);
router.post('/admin/tickets/:id/reopen',  authenticateToken, requireAdmin, SupportController.reopenTicket);

export default router;
